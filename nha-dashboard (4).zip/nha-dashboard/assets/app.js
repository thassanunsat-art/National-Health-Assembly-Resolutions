/* =========================================================================
   NHA Resolutions Dashboard
   Vanilla JS + hand-built SVG charts. No runtime dependencies.
   ========================================================================= */
(function () {
  "use strict";

  /* ───────────────────────── constants ───────────────────────── */

  var ALL = "__all__";
  var VIEWS = ["overview", "groups", "orgs", "cabinet"];

  // Resolution status — validated 5-slot categorical set, fixed order.
  var STATUS = [
    { key: "Achieved",              v: "--st-achieved"  },
    { key: "On-going",              v: "--st-ongoing"   },
    { key: "To be revisited",       v: "--st-revisit"   },
    { key: "To find key mechanism", v: "--st-mechanism" },
    { key: "End-up",                v: "--st-endup"     }
  ];
  function stLabel(k) { return I18N.status(k); }
  var STATUS_BY = {};
  STATUS.forEach(function (s) { STATUS_BY[s.key] = s; });

  var SECTOR_VARS = ["--sec-1", "--sec-2", "--sec-3", "--sec-4", "--sec-5"];

  // One colour map for cabinet-submission status, shared by the KPI tiles,
  // the donut and the table column so the same state always reads the same.
  var CAB_VAR = {
    "ครั้งที่ 1": "--st-achieved",
    "ครั้งที่ 2": "--st-ongoing",
    "อยู่ระหว่างเสนอ ครม.": "--st-revisit",
    "ไม่เสนอเรื่องเข้า ครม.": "--st-endup",
    "ไม่มีข้อมูล": "--muted"
  };
  function cabColor(key) { return cssVar(CAB_VAR[key] || "--muted"); }
  function cabPill(key) {
    return '<span class="pill"><span class="dot" style="background:' + cabColor(key) + '"></span>' +
      esc(I18N.cab(key)) + "</span>";
  }

  /* ───────────────────────── tiny DOM/SVG utils ───────────────────────── */

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var NS = "http://www.w3.org/2000/svg";

  function el(tag, attrs, parent) {
    var n = document.createElementNS(NS, tag);
    if (attrs) for (var k in attrs) if (attrs[k] != null) n.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(n);
    return n;
  }
  function h(tag, attrs, parent) {
    var n = document.createElement(tag);
    if (attrs) for (var k in attrs) {
      if (k === "text") n.textContent = attrs[k];
      else if (k === "html") n.innerHTML = attrs[k];
      else if (k === "cls") n.className = attrs[k];
      else if (attrs[k] != null) n.setAttribute(k, attrs[k]);
    }
    if (parent) parent.appendChild(n);
    return n;
  }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || "#888";
  }
  function n0(x) { return I18N.num(x); }
  function T(k) { return I18N.t(k); }
  function gLabel(g) { return I18N.group(g); }
  function iLabel(i) { return I18N.issue(i); }
  function sLabel(s2) { return I18N.sector(s2); }
  function pct(a, b) { return b ? Math.round((a / b) * 100) : 0; }
  function truncate(s, n) { s = String(s || ""); return s.length > n ? s.slice(0, n - 1) + "…" : s; }

  /** Readable ink for a filled cell — luminance-based, so it holds in both themes. */
  function inkOn(hex) {
    var m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(String(hex).trim());
    if (!m) return cssVar("--text-1");
    var c = [1, 2, 3].map(function (i) {
      var v = parseInt(m[i], 16) / 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    var L = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
    return L > 0.36 ? "#0b0b0b" : "#ffffff";
  }

  /** Rounded bar path: rounds only the "data end". */
  function barPathH(x, y, w, hh, r) {
    r = Math.max(0, Math.min(r, w, hh / 2));
    if (w <= 0.5) return "M" + x + "," + y + "h" + Math.max(w, 0.5) + "v" + hh + "h" + -Math.max(w, 0.5) + "z";
    return "M" + x + "," + y + "h" + (w - r) + "a" + r + "," + r + " 0 0 1 " + r + "," + r +
           "v" + (hh - 2 * r) + "a" + r + "," + r + " 0 0 1 " + -r + "," + r + "h" + -(w - r) + "z";
  }
  function barPathV(x, y, w, hh, r) {
    r = Math.max(0, Math.min(r, w / 2, hh));
    if (hh <= 0.5) return "M" + x + "," + (y + hh) + "h" + w + "v" + -Math.max(hh, 0.5) + "h" + -w + "z";
    return "M" + x + "," + (y + hh) + "v" + -(hh - r) + "a" + r + "," + r + " 0 0 1 " + r + "," + -r +
           "h" + (w - 2 * r) + "a" + r + "," + r + " 0 0 1 " + r + "," + r + "v" + (hh - r) + "z";
  }

  /* ───────────────────────── tooltip ───────────────────────── */

  var tip = $("#tooltip");
  function showTip(evt, html) {
    tip.innerHTML = html;
    tip.hidden = false;
    var pad = 14, r = tip.getBoundingClientRect();
    var x = evt.clientX + pad, y = evt.clientY + pad;
    if (x + r.width > innerWidth - 8) x = evt.clientX - r.width - pad;
    if (y + r.height > innerHeight - 8) y = evt.clientY - r.height - pad;
    tip.style.left = Math.max(8, x) + "px";
    tip.style.top = Math.max(8, y) + "px";
  }
  function hideTip() { tip.hidden = true; }
  function bindTip(node, htmlFn) {
    node.addEventListener("mousemove", function (e) { showTip(e, htmlFn()); });
    node.addEventListener("mouseleave", hideTip);
  }
  function ttRow(color, label, value) {
    return '<div class="tt-row">' +
      (color ? '<span class="swatch" style="background:' + color + '"></span>' : "") +
      "<span>" + esc(label) + "</span>" + (value != null ? "<b>" + esc(value) + "</b>" : "") + "</div>";
  }

  /* ───────────────────────── chart primitives ───────────────────────── */

  /**
   * Horizontal bars. items: [{label, value, color?, sub?, segs?}]
   * segs (optional) makes it a stacked bar: [{key,value,color}]
   */
  function hBar(mount, items, opts) {
    opts = opts || {};
    mount.innerHTML = "";
    if (!items.length) { mount.innerHTML = '<p class="empty">' + esc(T("u.noData")) + "</p>"; return; }

    var W = Math.max(mount.clientWidth || 600, 320);
    var labelW = opts.labelW || Math.min(Math.round(W * 0.42), 300);
    var valueW = 46;
    var rowH = opts.rowH || 26, gap = opts.gap || 8;
    var H = items.length * (rowH + gap) - gap + 6;
    var plotX = labelW + 10, plotW = Math.max(W - plotX - valueW, 40);
    var max = Math.max.apply(null, items.map(function (d) { return d.value; })).valueOf() || 1;
    var sx = function (v) { return (v / max) * plotW; };

    var svg = el("svg", { viewBox: "0 0 " + W + " " + H, role: "img" }, mount);
    var base = cssVar("--seq-450");

    items.forEach(function (d, i) {
      var y = i * (rowH + gap);

      var lab = el("text", {
        x: labelW, y: y + rowH / 2 + 4, "text-anchor": "end", class: "ax-label"
      }, svg);
      lab.textContent = truncate(d.label, Math.floor(labelW / 6.4));
      if (d.label.length > Math.floor(labelW / 6.4)) el("title", {}, lab).textContent = d.label;

      var g = el("g", { class: "mark" }, svg);
      if (d.segs && d.segs.length) {
        var acc = 0;
        d.segs.forEach(function (s, si) {
          if (!s.value) return;
          var w = sx(s.value), last = si === d.segs.length - 1;
          var seg = el("path", {
            d: barPathH(plotX + acc, y, Math.max(w - (last ? 0 : 2), 1), rowH, last ? 4 : 0),
            fill: s.color
          }, g);
          bindTip(seg, (function (s2, d2) {
            return function () {
              return "<strong>" + esc(d2.label) + "</strong>" +
                ttRow(s2.color, s2.label || s2.key, n0(s2.value) + " (" + pct(s2.value, d2.value) + "%)") +
                ttRow(null, opts.unit || T("u.total"), n0(d2.value));
            };
          })(s, d));
          seg.style.cursor = "pointer";
          acc += w;
        });
      } else {
        var p = el("path", { d: barPathH(plotX, y, sx(d.value), rowH, 4), fill: d.color || base }, g);
        bindTip(p, (function (d2) {
          return function () {
            return "<strong>" + esc(d2.label) + "</strong>" +
              ttRow(d2.color || base, opts.unit || T("u.count"), n0(d2.value)) +
              (d2.sub ? '<div class="tt-row"><span>' + esc(d2.sub) + "</span></div>" : "");
          };
        })(d));
        p.style.cursor = "pointer";
      }

      el("text", { x: plotX + sx(d.value) + 7, y: y + rowH / 2 + 4, class: "bar-label" }, svg)
        .textContent = n0(d.value);

      if (opts.onClick) {
        var hit = el("rect", { x: 0, y: y, width: W, height: rowH, class: "hit" }, svg);
        hit.addEventListener("click", function () { opts.onClick(d); });
        bindTip(hit, (function (d2) {
          return function () {
            return "<strong>" + esc(d2.label) + "</strong>" +
              ttRow(null, opts.unit || T("u.count"), n0(d2.value)) +
              '<div class="tt-row" style="color:var(--muted)">' + esc(T("u.clickDetail")) + "</div>";
          };
        })(d));
      }
    });
  }

  /** Vertical bars. items: [{label, value, segs?}] */
  function vBar(mount, items, opts) {
    opts = opts || {};
    mount.innerHTML = "";
    if (!items.length) { mount.innerHTML = '<p class="empty">' + esc(T("u.noData")) + "</p>"; return; }

    var W = Math.max(mount.clientWidth || 600, 320);
    var H = opts.height || 240;
    var padL = 34, padR = 8, padT = 12, padB = 30;
    var plotW = W - padL - padR, plotH = H - padT - padB;
    var max = Math.max.apply(null, items.map(function (d) { return d.value; })).valueOf() || 1;
    var nice = niceMax(max);
    var step = plotW / items.length;
    var bw = Math.max(Math.min(step - 8, 42), 4);
    var sy = function (v) { return (v / nice) * plotH; };

    var svg = el("svg", { viewBox: "0 0 " + W + " " + H, role: "img" }, mount);

    ticks(nice, 4).forEach(function (t) {
      var y = padT + plotH - sy(t);
      el("line", { x1: padL, x2: W - padR, y1: y, y2: y, class: t === 0 ? "baseline" : "gridline" }, svg);
      el("text", { x: padL - 7, y: y + 4, "text-anchor": "end", class: "ax-value" }, svg).textContent = n0(t);
    });

    items.forEach(function (d, i) {
      var cx = padL + i * step + step / 2;
      var g = el("g", { class: "mark" }, svg);
      if (d.segs && d.segs.length) {
        var acc = 0;
        d.segs.forEach(function (s, si) {
          if (!s.value) return;
          var hh = sy(s.value), last = si === d.segs.length - 1;
          el("path", {
            d: barPathV(cx - bw / 2, padT + plotH - acc - hh, bw, Math.max(hh - (last ? 0 : 2), 1), last ? 4 : 0),
            fill: s.color
          }, g);
          acc += hh;
        });
      } else {
        el("path", {
          d: barPathV(cx - bw / 2, padT + plotH - sy(d.value), bw, sy(d.value), 4),
          fill: opts.color || cssVar("--seq-450")
        }, g);
      }

      if (items.length <= 22 || i % 2 === 0) {
        el("text", { x: cx, y: H - 10, "text-anchor": "middle", class: "ax-label" }, svg).textContent = d.label;
      }

      var hit = el("rect", { x: padL + i * step, y: padT, width: step, height: plotH, class: "hit" }, svg);
      bindTip(hit, (function (d2) {
        return function () {
          var s = "<strong>" + esc(opts.xTitle ? opts.xTitle + " " + d2.label : d2.label) + "</strong>";
          if (d2.segs) d2.segs.forEach(function (sg) { if (sg.value) s += ttRow(sg.color, sg.label || sg.key, n0(sg.value)); });
          s += ttRow(d2.segs ? null : (opts.color || cssVar("--seq-450")), opts.unit || T("u.count"), n0(d2.value));
          return s;
        };
      })(d));
      if (opts.onClick) { hit.addEventListener("click", function () { opts.onClick(d); }); }
    });
  }

  function niceMax(m) {
    if (m <= 5) return Math.max(m, 1);
    var mag = Math.pow(10, Math.floor(Math.log10(m)));
    return Math.ceil(m / (mag / 2)) * (mag / 2);
  }
  function ticks(max, n) {
    var out = [];
    for (var i = 0; i <= n; i++) out.push(Math.round((max / n) * i));
    return out.filter(function (v, i, a) { return a.indexOf(v) === i; });
  }

  /** Donut with a hero number in the middle. items: [{label, value, color}] */
  function donut(mount, items, opts) {
    opts = opts || {};
    mount.innerHTML = "";
    var total = items.reduce(function (a, b) { return a + b.value; }, 0);
    if (!total) { mount.innerHTML = '<p class="empty">' + esc(T("u.noData")) + "</p>"; return; }

    var W = Math.max(mount.clientWidth || 400, 280);
    var size = Math.min(W, 260), cx = W / 2, cy = size / 2;
    var R = size / 2 - 6, r = R * 0.62;

    var svg = el("svg", { viewBox: "0 0 " + W + " " + (size + 4), role: "img" }, mount);
    var a0 = -Math.PI / 2;

    items.forEach(function (d) {
      if (!d.value) return;
      var a1 = a0 + (d.value / total) * Math.PI * 2;
      var p = el("path", { d: arcPath(cx, cy, R, r, a0, a1), fill: d.color, class: "mark" }, svg);
      p.setAttribute("stroke", cssVar("--surface"));
      p.setAttribute("stroke-width", "2");
      p.style.cursor = "pointer";
      bindTip(p, (function (d2) {
        return function () {
          return "<strong>" + esc(d2.label) + "</strong>" +
            ttRow(d2.color, T("u.count"), n0(d2.value)) +
            ttRow(null, T("u.share"), pct(d2.value, total) + "%");
        };
      })(d));
      if (opts.onClick) p.addEventListener("click", function () { opts.onClick(d); });
      a0 = a1;
    });

    el("text", { x: cx, y: cy - 2, "text-anchor": "middle", class: "hero-num" }, svg).textContent = n0(total);
    el("text", { x: cx, y: cy + 18, "text-anchor": "middle", class: "hero-sub" }, svg)
      .textContent = opts.centerLabel || T("u.total");

    // legend — identity is never colour-alone
    var lg = h("div", { cls: "legend" }, mount);
    items.forEach(function (d) {
      var b = h("button", { type: "button" }, lg);
      h("span", { cls: "swatch" }, b).style.background = d.color;
      h("span", { text: d.label }, b);
      h("span", { cls: "n", text: n0(d.value) + " · " + pct(d.value, total) + "%" }, b);
      if (opts.onClick) b.addEventListener("click", function () { opts.onClick(d); });
    });
  }

  function arcPath(cx, cy, R, r, a0, a1) {
    var big = a1 - a0 > Math.PI ? 1 : 0;
    var x0 = cx + R * Math.cos(a0), y0 = cy + R * Math.sin(a0);
    var x1 = cx + R * Math.cos(a1), y1 = cy + R * Math.sin(a1);
    var x2 = cx + r * Math.cos(a1), y2 = cy + r * Math.sin(a1);
    var x3 = cx + r * Math.cos(a0), y3 = cy + r * Math.sin(a0);
    return "M" + x0 + "," + y0 + "A" + R + "," + R + " 0 " + big + " 1 " + x1 + "," + y1 +
           "L" + x2 + "," + y2 + "A" + r + "," + r + " 0 " + big + " 0 " + x3 + "," + y3 + "Z";
  }

  /** Sequential heatmap. rows/cols: string[]; get(row,col) -> number */
  function heatmap(mount, rows, cols, get, opts) {
    opts = opts || {};
    mount.innerHTML = "";
    if (!rows.length || !cols.length) { mount.innerHTML = '<p class="empty">' + esc(T("u.noData")) + "</p>"; return; }

    var labelW = opts.labelW || 210;
    var cell = opts.cell || 44, rowH = 30, headH = 74;
    var W = Math.max(labelW + cols.length * cell + 8, mount.clientWidth || 600);
    var H = headH + rows.length * rowH + 8;
    var svg = el("svg", { viewBox: "0 0 " + W + " " + H, width: W, role: "img" }, mount);

    var max = 0;
    rows.forEach(function (rw) { cols.forEach(function (c) { max = Math.max(max, get(rw, c)); }); });
    max = max || 1;

    var ramp = ["--seq-100", "--seq-200", "--seq-300", "--seq-400", "--seq-450", "--seq-550", "--seq-650"]
      .map(function (v) { return cssVar(v); });

    cols.forEach(function (c, ci) {
      var x = labelW + ci * cell + cell / 2;
      var t = el("text", {
        x: x, y: headH - 10, class: "ax-label",
        transform: "rotate(-40 " + x + " " + (headH - 10) + ")", "text-anchor": "start"
      }, svg);
      t.textContent = truncate(c, 18);
      el("title", {}, t).textContent = c;
    });

    rows.forEach(function (rw, ri) {
      var y = headH + ri * rowH;
      var lt = el("text", { x: labelW - 10, y: y + rowH / 2 + 4, "text-anchor": "end", class: "ax-label" }, svg);
      lt.textContent = truncate(rw, Math.floor(labelW / 6.6));
      el("title", {}, lt).textContent = rw;

      cols.forEach(function (c, ci) {
        var v = get(rw, c);
        var idx = v === 0 ? -1 : Math.min(ramp.length - 1, Math.floor((v / max) * (ramp.length - 1) + 0.001));
        var x = labelW + ci * cell;
        var rect = el("rect", {
          x: x + 1, y: y + 1, width: cell - 3, height: rowH - 3, rx: 4,
          fill: idx < 0 ? cssVar("--surface-2") : ramp[idx], class: "mark"
        }, svg);
        if (v) {
          el("text", {
            x: x + cell / 2 - 1, y: y + rowH / 2 + 4, "text-anchor": "middle",
            class: "bar-label", fill: inkOn(ramp[idx])
          }, svg).textContent = v;
        }
        bindTip(rect, (function (rw2, c2, v2) {
          return function () {
            return "<strong>" + esc(rw2) + "</strong>" + ttRow(null, c2, n0(v2));
          };
        })(rw, c, v));
      });
    });
  }

  /* ───────────────────────── sortable table ───────────────────────── */

  function table(mount, cols, rows, onRow) {
    mount.innerHTML = "";
    if (!rows.length) { mount.innerHTML = '<p class="empty">' + esc(T("u.noRows")) + "</p>"; return; }

    var state = mount._sort || { key: null, dir: 1 };
    var data = rows.slice();
    if (state.key) {
      var col = cols.filter(function (c) { return c.key === state.key; })[0];
      data.sort(function (a, b) {
        var x = col.sort ? col.sort(a) : a[state.key], y = col.sort ? col.sort(b) : b[state.key];
        if (typeof x === "number" && typeof y === "number") return (x - y) * state.dir;
        return String(x).localeCompare(String(y), "th") * state.dir;
      });
    }

    var t = h("table", {}, mount);
    var thead = h("thead", {}, t), tr = h("tr", {}, thead);
    cols.forEach(function (c) {
      var th = h("th", { cls: c.num ? "num" : "", scope: "col" }, tr);
      th.innerHTML = esc(c.label) + (state.key === c.key ? ' <span class="arrow">' + (state.dir > 0 ? "▲" : "▼") + "</span>" : "");
      th.addEventListener("click", function () {
        mount._sort = { key: c.key, dir: state.key === c.key ? -state.dir : (c.num ? -1 : 1) };
        table(mount, cols, rows, onRow);
      });
    });

    var tb = h("tbody", {}, t);
    data.forEach(function (r) {
      var row = h("tr", { tabindex: "0" }, tb);
      cols.forEach(function (c) {
        var td = h("td", { cls: c.num ? "num" : "" }, row);
        td.innerHTML = c.render ? c.render(r) : esc(r[c.key]);
      });
      if (onRow) {
        row.addEventListener("click", function () { onRow(r); });
        row.addEventListener("keydown", function (e) { if (e.key === "Enter") onRow(r); });
      }
    });
  }

  /** Google Drive folder for a resolution: exact match, or its assembly's. */
  function docCell(r) {
    if (!r.docLink) return '<span style="color:var(--muted)">—</span>';
    var title = T(r.docScope === "assembly" ? "d.docAssembly" : "d.docExact");
    return '<a class="doc-link" href="' + esc(r.docLink) + '" target="_blank" rel="noopener"' +
      ' title="' + esc(title) + '" aria-label="' + esc(title) + '"' +
      ' onclick="event.stopPropagation()">' +
      '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" ' +
      'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      '<path d="M4 6a2 2 0 0 1 2-2h3l2 2h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/></svg>' +
      (r.docScope === "assembly" ? '<i class="doc-scope" aria-hidden="true">' +
        esc(String(r.assembly)) + "</i>" : "") + "</a>";
  }

  function statusPill(key) {
    var s = STATUS_BY[key];
    var color = s ? cssVar(s.v) : cssVar("--muted");
    return '<span class="pill"><span class="dot" style="background:' + color + '"></span>' +
      esc(stLabel(key)) + "</span>";
  }

  /* ───────────────────────── state ───────────────────────── */

  var DATA = null;
  var view = "overview";
  var filters = { year: ALL, group: ALL, status: ALL, sector: ALL, q: "" };
  var F = null;               // current filtered slice
  var resById = {}, actsByRes = {}, cabById = {};

  /* ───────────────────────── filtering ───────────────────────── */

  function textOfRes(r) {
    return (r.id + " " + r.name + " " + r.group + " " + r.source + " " + r.sourceDetail).toLowerCase();
  }
  function textOfAct(a) {
    return (a.org + " " + a.issue + " " + a.detail).toLowerCase();
  }

  function applyFilters() {
    var q = filters.q.trim().toLowerCase();

    var res = DATA.resolutions.filter(function (r) {
      return (filters.year === ALL || String(r.year) === filters.year) &&
             (filters.group === ALL || r.group === filters.group) &&
             (filters.status === ALL || r.status === filters.status);
    });

    var acts = DATA.actions.filter(function (a) {
      return filters.sector === ALL || a.orgGroup === filters.sector;
    });

    if (filters.sector !== ALL) {
      var withSector = {};
      acts.forEach(function (a) { withSector[a.resId] = 1; });
      res = res.filter(function (r) { return withSector[r.id]; });
    }

    if (q) {
      res = res.filter(function (r) {
        if (textOfRes(r).indexOf(q) >= 0) return true;
        var list = actsByRes[r.id] || [];
        for (var i = 0; i < list.length; i++) {
          if (textOfAct(list[i]).indexOf(q) >= 0 &&
              (filters.sector === ALL || list[i].orgGroup === filters.sector)) return true;
        }
        return false;
      });
    }

    var ids = {};
    res.forEach(function (r) { ids[r.id] = 1; });
    acts = acts.filter(function (a) { return ids[a.resId]; });
    if (q) {
      acts = acts.filter(function (a) {
        return textOfAct(a).indexOf(q) >= 0 || textOfRes(resById[a.resId] || { id: "", name: "", group: "", source: "", sourceDetail: "" }).indexOf(q) >= 0;
      });
    }

    var links = DATA.cabinetLinks.filter(function (l) { return ids[l.resId]; });
    var cabIds = {};
    links.forEach(function (l) { if (l.cabId) cabIds[l.cabId] = 1; });
    var pristine = filters.year === ALL && filters.group === ALL &&
                   filters.status === ALL && filters.sector === ALL && !q;
    var cab = DATA.cabinet.filter(function (c) {
      // cabinet resolutions with no linked NHA resolution only surface unfiltered
      return cabIds[c.id] || (pristine && !c.resolutions.length);
    });

    F = { res: res, acts: acts, links: links, cab: cab, ids: ids };
  }

  /* ───────────────────────── aggregation helpers ───────────────────────── */

  function countBy(arr, fn) {
    var m = {};
    arr.forEach(function (d) { var k = fn(d); if (k == null || k === "") return; m[k] = (m[k] || 0) + 1; });
    return m;
  }
  /** `label` is what the reader sees; `key` stays the raw value for filtering. */
  function toItems(map, colorFn, labelFn) {
    return Object.keys(map).map(function (k) {
      return { key: k, label: labelFn ? labelFn(k) : k, value: map[k], color: colorFn ? colorFn(k) : null };
    }).sort(function (a, b) { return b.value - a.value; });
  }
  function statusSegs(list) {
    var m = countBy(list, function (r) { return r.status; });
    return STATUS.map(function (s) {
      return { key: s.key, label: stLabel(s.key), value: m[s.key] || 0, color: cssVar(s.v) };
    }).filter(function (s) { return s.value > 0; });
  }
  function sectorColor(name) {
    var idx = DATA.dims.orgGroups.indexOf(name);
    return cssVar(SECTOR_VARS[(idx < 0 ? 0 : idx) % SECTOR_VARS.length]);
  }
  /** "กลุ่มมติ 12 …" → "12. …"; in English the vocabulary is already numbered. */
  function shortGroup(g) {
    var label = gLabel(g);
    return label === g ? g.replace(/^กลุ่มมติ\s*(\d+)\s*/, "$1. ").trim() : label;
  }

  /* ───────────────────────── KPI tiles ───────────────────────── */

  function kpis(mount, list) {
    mount.innerHTML = "";
    list.forEach(function (k) {
      var c = h("div", { cls: "kpi" }, mount);
      // the dot repeats what the label already says — colour is never the only cue
      h("span", {
        cls: "label",
        html: (k.color ? '<span class="dot" style="background:' + k.color + '"></span>' : "") + esc(k.label)
      }, c);
      h("div", { cls: "value", text: n0(k.value) + (k.suffix || "") }, c);
      if (k.sub) h("div", { cls: "sub", text: k.sub }, c);
      if (k.ratio != null) {
        var bar = h("div", { cls: "bar" }, c);
        var fill = h("i", {}, bar);
        fill.style.width = Math.max(2, Math.round(k.ratio * 100)) + "%";
        if (k.color) fill.style.background = k.color;
      }
    });
  }

  /* ───────────────────────── views ───────────────────────── */

  function renderOverview() {
    var res = F.res, acts = F.acts;
    var achieved = res.filter(function (r) { return r.status === "Achieved"; }).length;
    var ongoing = res.filter(function (r) { return r.status === "On-going"; }).length;
    var orgs = {}; acts.forEach(function (a) { orgs[a.org] = 1; });

    var ofSel = function (v) { return pct(v, res.length) + "% " + T("u.ofSelected"); };
    kpis($("#kpiRow"), [
      { label: T("k.res"), value: res.length,
        sub: T("u.ofAll") + " " + n0(DATA.resolutions.length),
        ratio: res.length / DATA.resolutions.length, color: cssVar("--accent") },
      { label: T("k.achieved"), value: achieved, sub: ofSel(achieved),
        ratio: res.length ? achieved / res.length : 0, color: cssVar("--st-achieved") },
      { label: T("k.ongoing"), value: ongoing, sub: ofSel(ongoing),
        ratio: res.length ? ongoing / res.length : 0, color: cssVar("--st-ongoing") },
      { label: T("k.actions"), value: acts.length,
        sub: T("u.by") + " " + n0(Object.keys(orgs).length) + " " + T("u.orgsWord") },
      { label: T("k.cabRes"), value: F.cab.length,
        sub: n0(res.filter(function (r) { return r.cabinetStatus.indexOf("ครั้งที่") === 0; }).length) +
             " " + T("u.submittedSuffix") }
    ]);

    donut($("#chStatus"), statusSegs(res).map(function (s) {
      return { label: s.label, value: s.value, color: s.color, key: s.key };
    }), {
      centerLabel: T("u.resolutions"),
      onClick: function (d) {
        filters.status = filters.status === d.key ? ALL : d.key;
        $("#fStatus").value = filters.status; refresh();
      }
    });

    var byYear = countBy(res, function (r) { return r.year; });
    var years = DATA.dims.years.filter(function (y) { return byYear[y]; });
    vBar($("#chYear"), years.map(function (y) {
      return { label: String(y).slice(2), value: byYear[y], year: y };
    }), {
      height: 230, xTitle: T("u.beYear"), unit: T("u.resolutions"),
      onClick: function (d) { filters.year = String(d.year); $("#fYear").value = filters.year; refresh(); }
    });

    vBar($("#chYearStatus"), years.map(function (y) {
      var sub = res.filter(function (r) { return r.year === y; });
      return { label: String(y).slice(2), value: sub.length, segs: statusSegs(sub), year: y };
    }), { height: 250, xTitle: T("u.beYear"), unit: T("u.total") });
    legendFor($("#chYearStatus"), STATUS.map(function (s) {
      return { label: stLabel(s.key), color: cssVar(s.v) };
    }));

    table($("#tblResolutions"), [
      { key: "id", label: T("t.id"), render: function (r) { return '<span class="cell-main">' + esc(r.id) + "</span>"; } },
      { key: "title", label: T("t.title"),
        render: function (r) {
          return '<span class="cell-main">' + esc(truncate(r.title, 90)) + "</span>" +
                 '<span class="cell-sub">' + esc(shortGroup(r.group)) + "</span>";
        } },
      { key: "year", label: T("t.year"), num: true },
      { key: "status", label: T("t.status"), render: function (r) { return statusPill(r.status); } },
      { key: "drivenCount", label: T("t.actions"), num: true },
      { key: "orgCount", label: T("t.orgs"), num: true },
      { key: "cabinetStatus", label: T("t.cabinet"), render: function (r) { return cabPill(r.cabinetStatus); } },
      { key: "docLink", label: T("t.doc"), render: docCell }
    ], res, openResolution);
  }

  function renderGroups() {
    var res = F.res, acts = F.acts;
    var groups = {};
    res.forEach(function (r) { (groups[r.group] = groups[r.group] || []).push(r); });
    var gkeys = Object.keys(groups).sort(function (a, b) { return groups[b].length - groups[a].length; });

    var issueCount = countBy(acts, function (a) { return a.issue; });
    var issueItems = toItems(issueCount, null, iLabel);
    var topIssue = issueItems[0];

    kpis($("#kpiGroups"), [
      { label: T("k.groups"), value: gkeys.length,
        sub: T("u.ofAll") + " " + n0(DATA.dims.groups.length) + " " + T("u.groupsWord") },
      { label: T("k.resHere"), value: res.length },
      { label: T("k.actTypes"), value: Object.keys(issueCount).length },
      { label: T("k.topType"), value: topIssue ? topIssue.value : 0,
        sub: topIssue ? topIssue.label : "—" }
    ]);

    hBar($("#chGroup"), gkeys.map(function (g) {
      return { label: shortGroup(g), value: groups[g].length, segs: statusSegs(groups[g]), full: g };
    }), {
      rowH: 24, unit: T("u.resolutions"), labelW: 280,
      onClick: function (d) { filters.group = d.full; $("#fGroup").value = d.full; refresh(); }
    });
    legendFor($("#chGroup"), STATUS.map(function (s) { return { label: stLabel(s.key), color: cssVar(s.v) }; }));

    hBar($("#chIssue"), issueItems, { rowH: 22, unit: T("u.actionsUnit"), labelW: 190 });

    var topRes = res.slice().sort(function (a, b) { return b.drivenCount - a.drivenCount; }).slice(0, 15)
      .filter(function (r) { return r.drivenCount > 0; });
    hBar($("#chTopRes"), topRes.map(function (r) {
      return { label: r.id + " " + truncate(r.title, 42), value: r.drivenCount, res: r };
    }), { rowH: 22, unit: T("u.actionsUnit"), labelW: 260, onClick: function (d) { openResolution(d.res); } });

    // the heatmap keys on the displayed labels, which stay one-to-one per language
    var gShort = gkeys.map(shortGroup);
    var issues = DATA.dims.issues.filter(function (i) { return issueCount[i]; }).map(iLabel);
    var cube = {};
    acts.forEach(function (a) {
      var r = resById[a.resId]; if (!r) return;
      var k = shortGroup(r.group) + "||" + iLabel(a.issue);
      cube[k] = (cube[k] || 0) + 1;
    });
    heatmap($("#chHeatGroup"), gShort, issues, function (rw, c) { return cube[rw + "||" + c] || 0; }, { labelW: 250 });
  }

  function renderOrgs() {
    var acts = F.acts;
    var bySector = countBy(acts, function (a) { return a.orgGroup; });
    var orgMap = {};
    acts.forEach(function (a) {
      var o = orgMap[a.org] || (orgMap[a.org] = { org: a.org, sector: a.orgGroup, n: 0, res: {}, issues: {} });
      o.n++; o.res[a.resId] = 1; o.issues[a.issue] = 1;
    });
    var orgs = Object.keys(orgMap).map(function (k) {
      var o = orgMap[k];
      return { org: o.org, sector: o.sector, actions: o.n, resCount: Object.keys(o.res).length, issueCount: Object.keys(o.issues).length };
    }).sort(function (a, b) { return b.actions - a.actions; });

    var gov = bySector["ภาครัฐ"] || 0;
    kpis($("#kpiOrgs"), [
      { label: T("k.orgs"), value: orgs.length },
      { label: T("k.actions"), value: acts.length,
        sub: orgs.length ? T("u.avg") + " " + (acts.length / orgs.length).toFixed(1) + " " + T("u.perOrg") : "" },
      { label: T("k.govShare"), value: pct(gov, acts.length), suffix: "%",
        sub: n0(gov) + " " + T("u.fromTotal") + " " + n0(acts.length) + " " + T("u.actionsUnit"),
        ratio: acts.length ? gov / acts.length : 0, color: cssVar("--sec-1") },
      { label: T("k.sectors"), value: Object.keys(bySector).length }
    ]);

    donut($("#chSector"), toItems(bySector, sectorColor, sLabel), {
      centerLabel: T("u.actionsUnit"),
      onClick: function (d) { filters.sector = filters.sector === d.key ? ALL : d.key; $("#fSector").value = filters.sector; refresh(); }
    });

    var sectors = Object.keys(bySector).sort(function (a, b) { return bySector[b] - bySector[a]; });
    var issues = DATA.dims.issues.filter(function (i) {
      return acts.some(function (a) { return a.issue === i; });
    }).map(iLabel);
    var cube = {};
    acts.forEach(function (a) { cube[sLabel(a.orgGroup) + "||" + iLabel(a.issue)] = (cube[sLabel(a.orgGroup) + "||" + iLabel(a.issue)] || 0) + 1; });
    heatmap($("#chHeatSector"), sectors.map(sLabel), issues,
      function (rw, c) { return cube[rw + "||" + c] || 0; }, { labelW: 150, cell: 40 });

    hBar($("#chTopOrg"), orgs.slice(0, 20).map(function (o) {
      return { label: o.org, value: o.actions, color: sectorColor(o.sector), sub: sLabel(o.sector), org: o };
    }), { rowH: 22, unit: T("u.actionsUnit"), labelW: 340, onClick: function (d) { openOrg(d.org); } });
    legendFor($("#chTopOrg"), sectors.map(function (s2) { return { label: sLabel(s2), color: sectorColor(s2) }; }));

    table($("#tblOrgs"), [
      { key: "org", label: T("t.org"),
        render: function (o) { return '<span class="cell-main">' + esc(o.org) + "</span>"; } },
      { key: "sector", label: T("t.sector"),
        render: function (o) {
          return '<span class="pill"><span class="dot" style="background:' + sectorColor(o.sector) + '"></span>' +
            esc(sLabel(o.sector)) + "</span>";
        } },
      { key: "actions", label: T("t.actions"), num: true },
      { key: "resCount", label: T("t.resDriven"), num: true },
      { key: "issueCount", label: T("t.workTypes"), num: true }
    ], orgs, openOrg);
  }

  function renderCabinet() {
    var res = F.res;
    var byStatus = countBy(res, function (r) { return r.cabinetStatus; });
    var submitted = res.filter(function (r) { return r.cabinetStatus.indexOf("ครั้งที่") === 0; }).length;

    var pending = byStatus["อยู่ระหว่างเสนอ ครม."] || 0;
    var notSub = byStatus["ไม่เสนอเรื่องเข้า ครม."] || 0;
    var noData = byStatus["ไม่มีข้อมูล"] || 0;
    var share = function (v) { return res.length ? v / res.length : 0; };

    var ofSel = function (v) { return pct(v, res.length) + "% " + T("u.ofSelected"); };
    kpis($("#kpiCab"), [
      { label: T("k.submitted"), value: submitted, sub: ofSel(submitted),
        ratio: share(submitted), color: cabColor("ครั้งที่ 1") },
      { label: T("k.pending"), value: pending, sub: ofSel(pending),
        ratio: share(pending), color: cabColor("อยู่ระหว่างเสนอ ครม.") },
      { label: T("k.notSub"), value: notSub, sub: ofSel(notSub),
        ratio: share(notSub), color: cabColor("ไม่เสนอเรื่องเข้า ครม.") },
      { label: T("k.noData"), value: noData, sub: ofSel(noData),
        ratio: share(noData), color: cabColor("ไม่มีข้อมูล") },
      { label: T("k.cabRes"), value: F.cab.length,
        sub: T("u.ofAll") + " " + n0(DATA.cabinet.length) + " " + T("u.docs") }
    ]);

    donut($("#chCabStatus"), Object.keys(byStatus).sort(function (a, b) { return byStatus[b] - byStatus[a]; })
      .map(function (k) {
        return { label: I18N.cab(k), value: byStatus[k], color: cabColor(k) };
      }), { centerLabel: T("u.resolutions") });

    var byYear = countBy(F.cab, function (c) { return c.year; });
    var yrs = Object.keys(byYear).sort();
    vBar($("#chCabYear"), yrs.map(function (y) { return { label: String(y).slice(2), value: byYear[y] }; }),
      { height: 230, xTitle: T("u.beYear"), unit: T("u.cabUnit") });

    var tl = $("#cabTimeline");
    tl.innerHTML = "";
    if (!F.cab.length) { tl.innerHTML = '<p class="empty">' + esc(T("u.noCab")) + "</p>"; return; }
    F.cab.slice().reverse().forEach(function (c) {
      var item = h("div", { cls: "tl-item" }, tl);
      h("div", { cls: "tl-date", text: c.date ? fmtDate(c.date) : "—" }, item);
      var rail = h("div", { cls: "tl-rail" }, item);
      h("div", { cls: "tl-dot" }, rail);
      var card = h("div", { cls: "tl-card", tabindex: "0", role: "button" }, item);
      h("p", { cls: "tl-title", text: c.title }, card);
      var meta = h("div", { cls: "tl-meta" }, card);
      h("span", { text: c.id }, meta);
      h("span", { text: c.resolutions.length + " " + T("d.relatedCount") }, meta);
      if (c.link) h("span", { text: T("d.hasAttach") }, meta);
      card.addEventListener("click", function () { openCabinet(c); });
      card.addEventListener("keydown", function (e) { if (e.key === "Enter") openCabinet(c); });
    });
  }

  /** The source carries Buddhist-era years in its date cells; English says so. */
  function fmtDate(iso) {
    var p = iso.split("-"), M = I18N.months();
    return Number(p[2]) + " " + M[Number(p[1]) - 1] + " " + Number(p[0]) +
      (I18N.lang === "en" ? " B.E." : "");
  }

  function legendFor(chartMount, items) {
    var lg = h("div", { cls: "legend" }, chartMount);
    items.forEach(function (d) {
      var b = h("button", { type: "button", disabled: "" }, lg);
      b.style.cursor = "default";
      h("span", { cls: "swatch" }, b).style.background = d.color;
      h("span", { text: d.label }, b);
    });
  }

  /* ───────────────────────── drawer ───────────────────────── */

  var drawer = $("#drawer"), scrim = $("#scrim"), drawerBody = $("#drawerBody");

  function openDrawer(html) {
    drawerBody.innerHTML = html;
    drawer.hidden = false; scrim.hidden = false;
    document.body.style.overflow = "hidden";
    drawer.scrollTop = 0;
    $("#drawerClose").focus();
  }
  function closeDrawer() {
    drawer.hidden = true; scrim.hidden = true; document.body.style.overflow = "";
  }
  $("#drawerClose").addEventListener("click", closeDrawer);
  scrim.addEventListener("click", closeDrawer);
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") { closeDrawer(); closeNav(); hideTip(); }
  });

  function openResolution(r) {
    var acts = (actsByRes[r.id] || []);
    var links = DATA.cabinetLinks.filter(function (l) { return l.resId === r.id && l.cabId; });

    var html = "<h3>" + esc(r.name) + "</h3>";
    html += '<div class="drawer-meta">' + statusPill(r.status) +
      '<span class="pill">' + esc(shortGroup(r.group)) + "</span>" +
      '<span class="pill">' + esc(T("u.beYear").slice(0, -2)) + " " + r.year + "</span></div>";

    html += "<h4>" + esc(T("d.origin")) + "</h4><dl class='def'>" +
      "<dt>" + esc(T("d.situation")) + "</dt><dd>" + esc(r.source || "—") + "</dd>" +
      "<dt>" + esc(T("d.details")) + "</dt><dd>" + esc(r.sourceDetail || "—") + "</dd>" +
      "<dt>" + esc(T("d.assembly")) + "</dt><dd>" + esc(T("d.assemblyVal")) + r.assembly + "</dd></dl>";

    html += "<h4>" + esc(T("d.docs")) + "</h4>";
    if (r.docLink) {
      html += '<p><a class="doc-btn" href="' + esc(r.docLink) + '" target="_blank" rel="noopener">' +
        '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" ' +
        'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
        '<path d="M4 6a2 2 0 0 1 2-2h3l2 2h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/></svg>' +
        esc(T("d.docOpen")) + " ↗</a> <span style=\"color:var(--muted);font-size:12px\">" +
        esc(T(r.docScope === "assembly" ? "d.docAssembly" : "d.docExact")) + "</span></p>";
    } else {
      html += '<p class="empty">' + esc(T("d.docNone")) + "</p>";
    }

    html += "<h4>" + esc(T("d.driving")) + " (" + acts.length + ")</h4>";
    if (!acts.length) html += '<p class="empty">' + esc(T("d.noDriving")) + "</p>";
    acts.forEach(function (a) {
      html += '<div class="act"><div class="act-head">' +
        '<span class="act-org">' + esc(a.org) + "</span>" +
        '<span class="pill"><span class="dot" style="background:' + sectorColor(a.orgGroup) + '"></span>' +
        esc(sLabel(a.orgGroup)) + "</span>" +
        '<span class="pill">' + esc(iLabel(a.issue)) + "</span></div>" +
        "<p>" + esc(a.detail || "—") + "</p></div>";
    });

    html += "<h4>" + esc(T("d.cabinet")) + " (" + links.length + ")</h4>";
    if (!links.length) html += '<div class="act">' + cabPill(r.cabinetStatus) + "</div>";
    links.forEach(function (l) {
      var c = cabById[l.cabId];
      html += '<div class="act"><div class="act-head"><span class="act-org">' + esc(l.cabTitle || (c && c.title) || l.cabId) + "</span>" +
        cabPill(l.cabStatus) + "</div>" +
        "<p>" + esc(l.cabId) + (c && c.date ? " · " + fmtDate(c.date) : "") + "</p>" +
        (c && c.detail ? "<p>" + esc(truncate(c.detail, 700)) + "</p>" : "") +
        (c && c.link ? '<p><a href="' + esc(c.link) + '" target="_blank" rel="noopener">' + esc(T("d.attachment")) + " ↗</a></p>" : "") +
        "</div>";
    });
    openDrawer(html);
  }

  function openOrg(o) {
    var name = o.org;
    var acts = DATA.actions.filter(function (a) { return a.org === name; });
    var html = "<h3>" + esc(name) + "</h3>" +
      '<div class="drawer-meta"><span class="pill"><span class="dot" style="background:' + sectorColor(o.sector) + '"></span>' +
      esc(sLabel(o.sector)) + "</span>" +
      '<span class="pill">' + acts.length + " " + esc(T("u.actionsUnit")) + "</span></div>";
    html += "<h4>" + esc(T("d.orgActions")) + "</h4>";
    acts.forEach(function (a) {
      var r = resById[a.resId];
      html += '<div class="act"><div class="act-head">' +
        '<span class="act-org">' + esc(a.resId) + " " + esc(r ? truncate(r.title, 70) : "") + "</span>" +
        '<span class="pill">' + esc(iLabel(a.issue)) + "</span>" +
        (r ? statusPill(r.status) : "") + "</div>" +
        "<p>" + esc(a.detail || "—") + "</p></div>";
    });
    openDrawer(html);
  }

  function openCabinet(c) {
    var html = "<h3>" + esc(c.title) + "</h3>" +
      '<div class="drawer-meta"><span class="pill">' + esc(c.id) + "</span>" +
      (c.date ? '<span class="pill">' + fmtDate(c.date) + "</span>" : "") +
      '<span class="pill">' + c.resolutions.length + " " + esc(T("d.relatedCount")) + "</span></div>";
    html += "<h4>" + esc(T("d.cabText")) + "</h4><p style='white-space:pre-line'>" + esc(c.detail) + "</p>";
    if (c.link) html += '<p><a href="' + esc(c.link) + '" target="_blank" rel="noopener">' + esc(T("d.attachment")) + " ↗</a></p>";
    html += "<h4>" + esc(T("d.linkedRes")) + "</h4>";
    c.resolutions.forEach(function (x) {
      var r = resById[x.id];
      html += '<div class="act"><div class="act-head"><span class="act-org">' + esc(x.name) + "</span>" +
        (r ? statusPill(r.status) : "") + "</div></div>";
    });
    openDrawer(html);
  }

  /* ───────────────────────── wiring ───────────────────────── */

  function fillSelect(sel, values, allLabel, labelFn) {
    sel.innerHTML = "";
    var o = h("option", { value: ALL, text: allLabel }, sel);
    values.forEach(function (v) {
      h("option", { value: String(v), text: labelFn ? labelFn(v) : String(v) }, sel);
    });
    return o;
  }

  /* The nav counts say how much each view is holding *right now*, so a filter
     shows its effect on every view without visiting them. */
  function navCounts() {
    var groups = {}, orgs = {};
    F.res.forEach(function (r) { groups[r.group] = 1; });
    F.acts.forEach(function (a) { orgs[a.org] = 1; });
    return {
      overview: F.res.length,
      groups: Object.keys(groups).length,
      orgs: Object.keys(orgs).length,
      cabinet: F.cab.length
    };
  }

  function paintHead() {
    $("#pageTitle").textContent = T("tab." + view);
    $("#pageDesc").textContent = T("nav." + view + ".d");
    if (!F) return;   // a language switch can land here before the first filter pass
    var counts = navCounts();
    VIEWS.forEach(function (v) {
      var cap = v.charAt(0).toUpperCase() + v.slice(1);
      var node = $("#navCount" + cap);
      if (node) {
        node.textContent = n0(counts[v]);
        node.title = n0(counts[v]) + " " + T("nav." + v + ".u");
      }
    });
  }

  /** One chip per active filter, each removable on its own. */
  function paintChips() {
    var box = $("#filterChips");
    box.innerHTML = "";
    var active = [
      { on: filters.year !== ALL, k: "f.year", v: filters.year, clear: function () { filters.year = ALL; $("#fYear").value = ALL; } },
      { on: filters.group !== ALL, k: "f.group", v: shortGroup(filters.group), clear: function () { filters.group = ALL; $("#fGroup").value = ALL; } },
      { on: filters.status !== ALL, k: "f.status", v: stLabel(filters.status), clear: function () { filters.status = ALL; $("#fStatus").value = ALL; } },
      { on: filters.sector !== ALL, k: "f.sector", v: sLabel(filters.sector), clear: function () { filters.sector = ALL; $("#fSector").value = ALL; } },
      { on: !!filters.q.trim(), k: "f.searchChip", v: filters.q, clear: function () { filters.q = ""; $("#fSearch").value = ""; } }
    ].filter(function (d) { return d.on; });

    active.forEach(function (d) {
      var c = h("span", { cls: "chip" }, box);
      h("b", { text: T(d.k) + ": " }, c);
      h("span", { text: d.v, title: d.v }, c);
      var x = h("button", { type: "button", text: "×", "aria-label": T("f.clearOne") + " — " + T(d.k) }, c);
      x.addEventListener("click", function () { d.clear(); refresh(); });
    });

    var badge = $("#filterBadge");
    badge.textContent = active.length;
    badge.hidden = active.length === 0;
    return active.length;
  }

  function refresh() {
    applyFilters();
    var nRes = F.res.length, nAll = DATA.resolutions.length;
    $("#filterCount").textContent = T("u.showing") + " " + n0(nRes) + " / " + n0(nAll) + " " +
      T("u.resolutions") + " · " + n0(F.acts.length) + " " + T("u.actionsUnit");

    paintHead();
    paintChips();

    VIEWS.forEach(function (v) { $("#view-" + v).hidden = v !== view; });
    if (view === "overview") renderOverview();
    else if (view === "groups") renderGroups();
    else if (view === "orgs") renderOrgs();
    else renderCabinet();
  }

  function boot(data) {
    DATA = data;
    data.resolutions.forEach(function (r) { resById[r.id] = r; });
    data.actions.forEach(function (a) { (actsByRes[a.resId] = actsByRes[a.resId] || []).push(a); });
    data.cabinet.forEach(function (c) { cabById[c.id] = c; });

    fillFilters();

    $("#fYear").addEventListener("change", function () { filters.year = this.value; refresh(); });
    $("#fGroup").addEventListener("change", function () { filters.group = this.value; refresh(); });
    $("#fStatus").addEventListener("change", function () { filters.status = this.value; refresh(); });
    $("#fSector").addEventListener("change", function () { filters.sector = this.value; refresh(); });

    var t;
    $("#fSearch").addEventListener("input", function () {
      var v = this.value;
      clearTimeout(t);
      t = setTimeout(function () { filters.q = v; refresh(); }, 220);
    });
    $("#fReset").addEventListener("click", function () {
      filters = { year: ALL, group: ALL, status: ALL, sector: ALL, q: "" };
      $("#fYear").value = ALL; $("#fGroup").value = ALL; $("#fStatus").value = ALL;
      $("#fSector").value = ALL; $("#fSearch").value = "";
      refresh();
    });

    Array.prototype.forEach.call(document.querySelectorAll(".tab"), function (b) {
      b.addEventListener("click", function () {
        Array.prototype.forEach.call(document.querySelectorAll(".tab"), function (x) {
          x.classList.toggle("is-active", x === b);
          x.setAttribute("aria-selected", x === b ? "true" : "false");
        });
        view = b.dataset.view;
        location.hash = view;
        closeNav();
        refresh();
      });
    });

    var hash = location.hash.replace("#", "");
    if (VIEWS.indexOf(hash) >= 0) {
      view = hash;
      var btn = document.querySelector('.tab[data-view="' + hash + '"]');
      if (btn) btn.click();
    }

    $("#loading").hidden = true;
    applyStaticText();
    refresh();

    var rt;
    addEventListener("resize", function () { clearTimeout(rt); rt = setTimeout(refresh, 180); });
  }

  /* ── the filter panel folds away; the chips keep it accountable ─────── */

  var filtersOpen = false;
  function setFilters(open) {
    filtersOpen = open;
    $("#filters").hidden = !open;
    var btn = $("#filterToggle");
    btn.setAttribute("aria-expanded", open ? "true" : "false");
    btn.querySelector("[data-i18n]").setAttribute("data-i18n", open ? "f.hide" : "f.show");
    btn.querySelector("[data-i18n]").textContent = T(open ? "f.hide" : "f.show");
  }
  $("#filterToggle").addEventListener("click", function () { setFilters(!filtersOpen); });

  /* ── off-canvas navigation (phone / tablet) ─────────────────────────── */

  function openNav() {
    $("#sidenav").classList.add("is-open");
    $("#navScrim").hidden = false;
    $("#navClose").focus();
  }
  function closeNav() {
    $("#sidenav").classList.remove("is-open");
    $("#navScrim").hidden = true;
  }
  $("#navOpen").addEventListener("click", openNav);
  $("#navClose").addEventListener("click", closeNav);
  $("#navScrim").addEventListener("click", closeNav);

  /* ── language ─────────────────────────────────────────────────────────
     Static markup carries data-i18n hooks; everything the charts draw is
     rebuilt from scratch by refresh(), so switching is a relabel + redraw. */

  function fillFilters() {
    var keep = { y: filters.year, g: filters.group, s: filters.status, c: filters.sector };
    fillSelect($("#fYear"), DATA.dims.years, T("f.allYears"));
    fillSelect($("#fGroup"), DATA.dims.groups, T("f.allGroups"), shortGroup);
    fillSelect($("#fStatus"), STATUS.map(function (s) { return s.key; }), T("f.allStatuses"), stLabel);
    fillSelect($("#fSector"), DATA.dims.orgGroups, T("f.allSectors"), sLabel);
    $("#fYear").value = keep.y; $("#fGroup").value = keep.g;
    $("#fStatus").value = keep.s; $("#fSector").value = keep.c;
  }

  function applyStaticText() {
    document.documentElement.lang = I18N.lang;
    document.title = T("doc.title");
    [["data-i18n", "textContent"], ["data-i18n-ph", "placeholder"],
     ["data-i18n-label", "aria-label"], ["data-i18n-alt", "alt"]].forEach(function (pair) {
      Array.prototype.forEach.call(document.querySelectorAll("[" + pair[0] + "]"), function (n) {
        var val = T(n.getAttribute(pair[0]));
        if (pair[1] === "textContent") n.textContent = val;
        else n.setAttribute(pair[1], val);
      });
    });
    Array.prototype.forEach.call(document.querySelectorAll(".lang-switch button"), function (b) {
      b.classList.toggle("is-on", b.dataset.lang === I18N.lang);
      b.setAttribute("aria-pressed", b.dataset.lang === I18N.lang ? "true" : "false");
    });
    setFilters(filtersOpen);
    if (DATA) {
      paintHead();
      $("#stamp").textContent = T("stamp") + DATA.meta.generated;
      $("#footMeta").textContent = DATA.meta.source + " · " +
        n0(DATA.meta.counts.resolutions) + " " + T("u.resolutions") + " · " +
        n0(DATA.meta.counts.actions) + " " + T("u.actionsUnit") + " · " +
        n0(DATA.meta.counts.orgs) + " " + T("u.orgsWord") + " · " +
        n0(DATA.meta.counts.cabinet) + " " + T("u.cabUnit");
    }
  }

  function setLang(l) {
    I18N.set(l);
    try { localStorage.setItem("nha-lang", I18N.lang); } catch (e) {}
    applyStaticText();
    if (DATA) { fillFilters(); refresh(); }
  }

  (function () {
    var saved = null;
    try { saved = localStorage.getItem("nha-lang"); } catch (e) {}
    // Thai is the default for a Thai agency's dashboard; the saved choice wins.
    I18N.set(saved || "th");
    applyStaticText();
    Array.prototype.forEach.call(document.querySelectorAll(".lang-switch button"), function (b) {
      b.addEventListener("click", function () { setLang(b.dataset.lang); });
    });
  })();

  /* theme toggle */
  (function () {
    var saved = null;
    try { saved = localStorage.getItem("nha-theme"); } catch (e) {}
    if (saved) document.documentElement.setAttribute("data-theme", saved);
    $("#themeToggle").addEventListener("click", function () {
      var cur = document.documentElement.getAttribute("data-theme");
      var sysDark = matchMedia("(prefers-color-scheme: dark)").matches;
      var next = cur ? (cur === "dark" ? "light" : "dark") : (sysDark ? "light" : "dark");
      document.documentElement.setAttribute("data-theme", next);
      try { localStorage.setItem("nha-theme", next); } catch (e) {}
      if (DATA) refresh();
    });
  })();

  /* load */
  fetch("data/nha_data.json")
    .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
    .then(boot)
    .catch(function (err) {
      $("#loading").innerHTML = esc(T("load.fail")) + "<br><small>" + esc(err.message) +
        "</small><br><small>" + esc(T("load.hint")) + "</small>";
    });
})();
