/* =========================================================================
   i18n — Thai / English strings for the NHA dashboard.

   Two layers:
     STR   UI chrome (titles, labels, buttons, table headers, tooltips)
     VOCAB the closed dimension vocabularies (groups, action types, sectors,
           statuses) that the charts aggregate on

   Record-level text — resolution titles, organization names, the body of each
   cabinet resolution — exists only in Thai in the source workbooks, so it is
   shown as-is in both languages. Years stay in the Buddhist Era the source
   uses; English mode labels them "B.E." rather than silently shifting them.
   ========================================================================= */
window.I18N = (function () {
  "use strict";

  var STR = {
    /* ── chrome ─────────────────────────────────────────────── */
    "doc.title":      ["แดชบอร์ดมติสมัชชาสุขภาพแห่งชาติ", "NHA Resolutions Dashboard"],
    "brand.title":    ["แดชบอร์ดมติสมัชชาสุขภาพแห่งชาติ", "National Health Assembly Resolutions"],
    "brand.sub":      ["สำนักงานคณะกรรมการสุขภาพแห่งชาติ (สช.)", "National Health Commission Office (NHCO)"],
    "brand.rail":     ["มติสมัชชาสุขภาพแห่งชาติ", "NHA Resolutions"],
    "brand.railSub":  ["สำนักงานคณะกรรมการสุขภาพแห่งชาติ (สช.)", "Nat. Health Commission Office"],
    "brand.alt":      ["ตราสัญลักษณ์สำนักงานคณะกรรมการสุขภาพแห่งชาติ (สช.)", "National Health Commission Office emblem"],
    "foot.alt":       ["สำนักงานคณะกรรมการสุขภาพแห่งชาติ", "National Health Commission Office"],
    "theme.toggle":   ["สลับโหมดสว่าง/มืด", "Toggle light / dark theme"],
    "lang.toggle":    ["เลือกภาษา", "Select language"],
    "stamp":          ["ข้อมูล ณ ", "Data as of "],
    "loading":        ["กำลังโหลดข้อมูล…", "Loading data…"],
    "load.fail":      ["โหลดข้อมูลไม่สำเร็จ", "Could not load the data"],
    "load.hint":      ["หากเปิดไฟล์จากเครื่องโดยตรง ให้รัน python3 -m http.server ก่อน",
                       "If you opened the file directly, serve it with python3 -m http.server first"],
    "views":          ["มุมมอง", "Views"],
    "filters":        ["ตัวกรอง", "Filters"],
    "detail":         ["รายละเอียด", "Detail"],
    "close":          ["ปิด", "Close"],

    /* ── navigation ─────────────────────────────────────────── */
    "tab.overview":   ["ภาพรวม", "Overview"],
    "tab.groups":     ["กลุ่มมติ & ประเด็น", "Groups & Issues"],
    "tab.orgs":       ["หน่วยงานขับเคลื่อน", "Organizations"],
    "tab.cabinet":    ["มติ ครม.", "Cabinet"],

    "nav.overview.d": ["สถานะและแนวโน้มรายปี", "Status and yearly trend"],
    "nav.groups.d":   ["ตามกลุ่มและประเภทงาน", "By group and work type"],
    "nav.orgs.d":     ["ใครขับเคลื่อนมติบ้าง", "Who drives the resolutions"],
    "nav.cabinet.d":  ["การเสนอเข้าคณะรัฐมนตรี", "Submission to the cabinet"],

    "nav.overview.u": ["มติ", "resolutions"],
    "nav.groups.u":   ["กลุ่ม", "groups"],
    "nav.orgs.u":     ["หน่วยงาน", "organizations"],
    "nav.cabinet.u":  ["ฉบับ", "documents"],

    "nav.menu":       ["เปิดเมนู", "Open menu"],
    "nav.close":      ["ปิดเมนู", "Close menu"],
    "nav.section":    ["มุมมองข้อมูล", "Data views"],
    "nav.settings":   ["การแสดงผล", "Display"],

    /* ── filters ────────────────────────────────────────────── */
    "f.year":         ["ปี พ.ศ.", "Year (B.E.)"],
    "f.group":        ["กลุ่มมติ", "Resolution group"],
    "f.status":       ["สถานะ", "Status"],
    "f.sector":       ["ภาคส่วน", "Sector"],
    "f.search":       ["ค้นหา", "Search"],
    "f.searchPh":     ["ชื่อมติ / หน่วยงาน / รายละเอียด…", "Resolution, organization, detail…"],
    "f.reset":        ["ล้างตัวกรอง", "Reset filters"],
    "f.show":         ["ตัวกรอง", "Filters"],
    "f.hide":         ["ซ่อนตัวกรอง", "Hide filters"],
    "f.none":         ["ยังไม่ได้กรอง — แสดงข้อมูลทั้งหมด", "No filters — showing everything"],
    "f.clearOne":     ["ล้างตัวกรองนี้", "Clear this filter"],
    "f.searchChip":   ["ค้นหา", "Search"],
    "f.allYears":     ["ทุกปี", "All years"],
    "f.allGroups":    ["ทุกกลุ่ม", "All groups"],
    "f.allStatuses":  ["ทุกสถานะ", "All statuses"],
    "f.allSectors":   ["ทุกภาคส่วน", "All sectors"],

    /* ── card headings ──────────────────────────────────────── */
    "c.status":       ["สถานะการขับเคลื่อนมติ", "Resolution status"],
    "c.status.d":     ["สัดส่วนมติตามสถานะการขับเคลื่อน ตามตัวกรองปัจจุบัน",
                       "Share of resolutions by driving status, for the current filters"],
    "c.year":         ["จำนวนมติรายปี", "Resolutions by year"],
    "c.year.d":       ["มติสมัชชาสุขภาพแห่งชาติ จำแนกตามปี พ.ศ. ที่มีมติ",
                       "National Health Assembly resolutions by the year they were passed"],
    "c.yearStatus":   ["องค์ประกอบสถานะรายปี", "Status composition by year"],
    "c.yearStatus.d": ["แต่ละแท่งคือมติของปีนั้น แบ่งตามสถานะการขับเคลื่อน",
                       "Each bar is one year's resolutions, split by driving status"],
    "c.resTable":     ["ตารางมติทั้งหมด", "All resolutions"],
    "c.resTable.d":   ["คลิกแถวเพื่อดูรายละเอียดการขับเคลื่อนและมติ ครม. ที่เกี่ยวข้อง",
                       "Click a row for its driving actions and linked cabinet resolutions"],

    "c.group":        ["มติแยกตามกลุ่มมติ", "Resolutions by group"],
    "c.group.d":      ["จำนวนมติในแต่ละกลุ่ม แบ่งสีตามสถานะการขับเคลื่อน",
                       "Resolutions per group, coloured by driving status"],
    "c.issue":        ["ประเภทการขับเคลื่อน", "Types of driving action"],
    "c.issue.d":      ["จำนวนกิจกรรมการขับเคลื่อน จำแนกตามประเภท",
                       "Driving actions by the type of work carried out"],
    "c.topRes":       ["ความเข้มข้นการขับเคลื่อนต่อมติ", "Actions per resolution"],
    "c.topRes.d":     ["มติที่มีกิจกรรมขับเคลื่อนมากที่สุด 15 อันดับแรก",
                       "The 15 resolutions with the most recorded driving actions"],
    "c.heatGroup":    ["กลุ่มมติ × ประเภทการขับเคลื่อน", "Group × action type"],
    "c.heatGroup.d":  ["จำนวนกิจกรรมขับเคลื่อนในแต่ละช่อง สีไล่ระดับตามจำนวน",
                       "Driving actions per cell; colour scales with the count"],

    "c.sector":       ["ภาคส่วนที่ขับเคลื่อน", "Driving sectors"],
    "c.sector.d":     ["สัดส่วนกิจกรรมขับเคลื่อน จำแนกตามภาคส่วนของหน่วยงาน",
                       "Share of driving actions by the sector of the organization"],
    "c.heatSector":   ["ภาคส่วน × ประเภทการขับเคลื่อน", "Sector × action type"],
    "c.heatSector.d": ["รูปแบบการทำงานที่แตกต่างกันของแต่ละภาคส่วน",
                       "How the working pattern differs from sector to sector"],
    "c.topOrg":       ["หน่วยงานขับเคลื่อนสูงสุด", "Most active organizations"],
    "c.topOrg.d":     ["20 อันดับแรก วัดจากจำนวนกิจกรรมขับเคลื่อนที่บันทึกไว้",
                       "Top 20 by number of recorded driving actions"],
    "c.orgTable":     ["ทะเบียนหน่วยงาน", "Organization register"],
    "c.orgTable.d":   ["คลิกแถวเพื่อดูรายการกิจกรรมขับเคลื่อนของหน่วยงานนั้น",
                       "Click a row to see that organization's driving actions"],

    "c.cabStatus":    ["สถานะการเสนอเข้า ครม.", "Cabinet submission status"],
    "c.cabStatus.d":  ["มติสมัชชาฯ จำแนกตามสถานะการนำเสนอคณะรัฐมนตรี",
                       "Assembly resolutions by how far they have reached the cabinet"],
    "c.cabYear":      ["มติ ครม. รายปี", "Cabinet resolutions by year"],
    "c.cabYear.d":    ["จำนวนมติคณะรัฐมนตรีที่เกี่ยวข้อง จำแนกตามปี พ.ศ.",
                       "Related cabinet resolutions, by year (B.E.)"],
    "c.timeline":     ["ไทม์ไลน์มติคณะรัฐมนตรี", "Cabinet resolution timeline"],
    "c.timeline.d":   ["คลิกเพื่อดูรายละเอียดมติ ครม. และมติสมัชชาฯ ที่เกี่ยวข้อง",
                       "Click an entry for the cabinet text and the resolutions it covers"],

    /* ── KPI tiles ──────────────────────────────────────────── */
    "k.res":          ["มติทั้งหมด", "Resolutions"],
    "k.achieved":     ["บรรลุผลแล้ว", "Achieved"],
    "k.ongoing":      ["กำลังขับเคลื่อน", "On-going"],
    "k.actions":      ["กิจกรรมขับเคลื่อน", "Driving actions"],
    "k.cabRes":       ["มติ ครม. ที่เกี่ยวข้อง", "Cabinet resolutions"],
    "k.groups":       ["กลุ่มมติที่ปรากฏ", "Groups present"],
    "k.resHere":      ["มติในมุมมองนี้", "Resolutions in view"],
    "k.actTypes":     ["ประเภทการขับเคลื่อน", "Action types"],
    "k.topType":      ["ประเภทที่พบมากสุด", "Most common type"],
    "k.orgs":         ["หน่วยงานทั้งหมด", "Organizations"],
    "k.govShare":     ["สัดส่วนภาครัฐ", "Public sector share"],
    "k.sectors":      ["ภาคส่วนที่ปรากฏ", "Sectors present"],
    "k.submitted":    ["เสนอ ครม. แล้ว", "Submitted to cabinet"],
    "k.pending":      ["อยู่ระหว่างเสนอ", "Awaiting submission"],
    "k.notSub":       ["ไม่เสนอเข้า ครม.", "Not submitted"],
    "k.noData":       ["ไม่มีข้อมูล", "No data"],

    /* ── table headers ──────────────────────────────────────── */
    "t.id":           ["รหัส", "ID"],
    "t.title":        ["ชื่อมติ", "Resolution"],
    "t.year":         ["ปี พ.ศ.", "Year (B.E.)"],
    "t.status":       ["สถานะ", "Status"],
    "t.actions":      ["กิจกรรม", "Actions"],
    "t.orgs":         ["หน่วยงาน", "Orgs"],
    "t.cabinet":      ["ครม.", "Cabinet"],
    "t.doc":          ["เอกสาร", "Files"],
    "t.org":          ["หน่วยงาน", "Organization"],
    "t.sector":       ["ภาคส่วน", "Sector"],
    "t.resDriven":    ["มติที่ขับเคลื่อน", "Resolutions driven"],
    "t.workTypes":    ["ประเภทงาน", "Action types"],

    /* ── running text ───────────────────────────────────────── */
    "u.count":        ["จำนวน", "Count"],
    "u.total":        ["รวม", "Total"],
    "u.share":        ["สัดส่วน", "Share"],
    "u.resolutions":  ["มติ", "resolutions"],
    "u.actionsUnit":  ["กิจกรรม", "actions"],
    "u.cabUnit":      ["มติ ครม.", "cabinet resolutions"],
    "u.clickDetail":  ["คลิกเพื่อดูรายละเอียด", "Click for detail"],
    "u.noData":       ["ไม่มีข้อมูลตามตัวกรอง", "No data for these filters"],
    "u.noRows":       ["ไม่มีรายการตามตัวกรอง", "No matching rows"],
    "u.noCab":        ["ไม่มีมติ ครม. ตามตัวกรอง", "No cabinet resolutions for these filters"],
    "u.beYear":       ["พ.ศ. 25", "B.E. 25"],
    "u.showing":      ["แสดง", "Showing"],
    "u.ofSelected":   ["ของมติที่เลือก", "of selected resolutions"],
    "u.ofAll":        ["จากทั้งหมด", "out of"],
    "u.by":           ["โดย", "across"],
    "u.orgsWord":     ["หน่วยงาน", "organizations"],
    "u.groupsWord":   ["กลุ่มทั้งหมด", "groups in total"],
    "u.docs":         ["ฉบับ", "documents"],
    "u.avg":          ["เฉลี่ย", "avg."],
    "u.perOrg":       ["กิจกรรม/หน่วยงาน", "actions per organization"],
    "u.fromTotal":    ["จาก", "of"],
    "u.submittedSuffix": ["มติผ่านการเสนอ ครม.", "resolutions reached the cabinet"],

    /* ── drawer ─────────────────────────────────────────────── */
    "d.origin":       ["ที่มาของมติ", "Origin"],
    "d.situation":    ["สถานการณ์", "Situation"],
    "d.details":      ["รายละเอียด", "Details"],
    "d.assembly":     ["ครั้งที่ประชุม", "Assembly"],
    "d.assemblyVal":  ["สมัชชาสุขภาพแห่งชาติ ครั้งที่ ", "National Health Assembly no. "],
    "d.driving":      ["การขับเคลื่อน", "Driving actions"],
    "d.noDriving":    ["ยังไม่มีข้อมูลการขับเคลื่อน", "No driving actions recorded yet"],
    "d.cabinet":      ["มติคณะรัฐมนตรี", "Cabinet resolutions"],
    "d.cabText":      ["สาระสำคัญของมติ ครม.", "Cabinet resolution text"],
    "d.linkedRes":    ["มติสมัชชาฯ ที่เกี่ยวข้อง", "Linked assembly resolutions"],
    "d.attachment":   ["เอกสารแนบ", "Attachment"],
    "d.docs":         ["เอกสารประกอบมติ", "Supporting documents"],
    "d.docOpen":      ["เปิดโฟลเดอร์เอกสาร", "Open document folder"],
    "d.docExact":     ["โฟลเดอร์เฉพาะมตินี้", "Folder for this resolution"],
    "d.docAssembly":  ["โฟลเดอร์รวมของสมัชชาครั้งนี้", "Folder for this whole assembly"],
    "d.docNone":      ["ยังไม่มีเอกสารแนบในไฟล์ต้นทาง", "No file listed in the source document"],
    "d.orgActions":   ["กิจกรรมขับเคลื่อน", "Driving actions"],
    "d.relatedCount": ["มติสมัชชาฯ ที่เกี่ยวข้อง", "linked assembly resolutions"],
    "d.hasAttach":    ["มีเอกสารแนบ", "Has an attachment"],

    /* ── footer ─────────────────────────────────────────────── */
    "foot.note":      ["สร้างจากชุดข้อมูล", "Built from the datasets"],
    "foot.static":    ["เว็บไซต์แบบ static ไม่มี backend", "Static site, no backend"]
  };

  /* ── dimension vocabularies ───────────────────────────────── */
  var GROUP_EN = {
    "กลุ่มมติ 1 เกษตร อาหารปลอดภัย และความมั่นคงทางอาหาร": "1. Agriculture, food safety & food security",
    "กลุ่มมติ 2 โรคจากการประกอบอาชีพ": "2. Occupational disease",
    "กลุ่มมติ 3 ผลกระทบจากสื่อต่อเด็ก เยาวชน และครอบครัว": "3. Media impact on children, youth & families",
    "กลุ่มมติ 4 การจัดการพื้นที่สาธารณะ ที่อยู่อาศัย ชุมชนและเมือง": "4. Public space, housing, community & cities",
    "กลุ่มมติ 5 สุขภาวะทางเพศ": "5. Sexual health",
    "กลุ่มมติ 6 มติที่เกี่ยวข้องกับปัจจัยทางเศรษฐกิจที่ส่งผลต่อสุขภาพ": "6. Economic determinants of health",
    "กลุ่มมติ 7 สุขภาวะชุมชนและสังคม": "7. Community & social wellbeing",
    "กลุ่มมติ 8 การจัดการด้านสิ่งแวดล้อม": "8. Environmental management",
    "กลุ่มมติ 9 มติที่เกี่ยวข้องกับยา": "9. Medicines",
    "กลุ่มมติ 10 การส่งเสริม ป้องกัน และควบคุมปัจจัยเสี่ยง": "10. Promotion, prevention & risk factors",
    "กลุ่มมติ 11 มติที่เกี่ยวข้องกับ NCDs": "11. Non-communicable diseases (NCDs)",
    "กลุ่มมติ 12 การพัฒนาระบบสุขภาพ": "12. Health system development",
    "กลุ่มมติ 13 การบริหารจัดการเพื่อป้องกันการแพร่ระบาดของโรค": "13. Epidemic prevention & management",
    "กลุ่มมติ 14 มติที่เกี่ยวกับกลุ่มเป้าหมายเฉพาะ": "14. Specific population groups",
    "กลุ่มมติ 15 ด้านสุขภาพจิต และความรุนแรงในสังคม": "15. Mental health & social violence",
    "อื่นๆ": "Other"
  };

  var ISSUE_EN = {
    "ข้อกฎหมาย/ประกาศคำสั่ง": "Law, regulation or order",
    "จัดทำยุทธศาสตร์/แผนแม่บท": "Strategy or master plan",
    "กิจกรรมโครงการ": "Projects & activities",
    "พัฒนาระบบและกลไก": "Systems & mechanisms",
    "รูปธรรมในระดับพื้นที่": "Local implementation",
    "ระบบข้อมูล": "Data systems",
    "นโยบาย": "Policy",
    "องค์ความรู้/งานวิจัย": "Knowledge & research",
    "สนับสนุนงบประมาณ/อุปกรณ์": "Budget & equipment support",
    "อยู่ในระหว่างการดำเนินงาน": "In progress"
  };

  var SECTOR_EN = {
    "ภาครัฐ": "Public sector",
    "ภาคประชาสังคม/เอกชน": "Civil society / private",
    "ภาควิชาการ": "Academic",
    "ภาคเอกชน": "Private sector",
    "องค์กรวิชาชีพ": "Professional bodies",
    "ไม่ระบุ": "Unspecified"
  };

  var CAB_LABEL = {
    "ครั้งที่ 1":            ["เสนอ ครม. แล้ว (ครั้งที่ 1)", "Submitted (1st round)"],
    "ครั้งที่ 2":            ["เสนอ ครม. แล้ว (ครั้งที่ 2)", "Submitted (2nd round)"],
    "อยู่ระหว่างเสนอ ครม.":   ["อยู่ระหว่างเสนอ ครม.", "Awaiting submission"],
    "ไม่เสนอเรื่องเข้า ครม.": ["ไม่เสนอเข้า ครม.", "Not submitted"],
    "ไม่มีข้อมูล":            ["ไม่มีข้อมูล", "No data"]
  };

  var STATUS_LABEL = {
    "Achieved":              ["บรรลุผล", "Achieved"],
    "On-going":              ["กำลังขับเคลื่อน", "On-going"],
    "To be revisited":       ["ต้องทบทวน", "To be revisited"],
    "To find key mechanism": ["ต้องหากลไกหลัก", "To find key mechanism"],
    "End-up":                ["ยุติการขับเคลื่อน", "Ended"]
  };

  var MONTHS = {
    th: ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."],
    en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  };

  var lang = "th";

  function idx() { return lang === "en" ? 1 : 0; }

  return {
    get lang() { return lang; },
    set: function (l) { lang = l === "en" ? "en" : "th"; },
    /** UI string by key. */
    t: function (key) {
      var row = STR[key];
      return row ? row[idx()] : key;
    },
    group:  function (v) { return lang === "en" ? (GROUP_EN[v] || v) : v; },
    issue:  function (v) { return lang === "en" ? (ISSUE_EN[v] || v) : v; },
    sector: function (v) { return lang === "en" ? (SECTOR_EN[v] || v) : v; },
    cab:    function (v) { var r = CAB_LABEL[v]; return r ? r[idx()] : v; },
    status: function (v) { var r = STATUS_LABEL[v]; return r ? r[idx()] : v; },
    months: function () { return MONTHS[lang]; },
    /** Number formatting follows the chosen language. */
    num:    function (v) { return Number(v || 0).toLocaleString(lang === "en" ? "en-US" : "th-TH"); }
  };
})();
