#!/usr/bin/env python3
"""
build_data.py — ETL for the NHA (สมัชชาสุขภาพแห่งชาติ) dashboard.

Reads the source Excel workbooks in data/source/ and writes a single
data/nha_data.json consumed by the static dashboard.

Usage:  python scripts/build_data.py
"""
from __future__ import annotations

import json
import re
import warnings
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

import pandas as pd

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "data" / "source"
OUT = ROOT / "data" / "nha_data.json"

F_NHA = SRC / "NHA_1.xlsx"
F_CAB_LINK = SRC / "Cabinet-resolution_NHCO.xlsx"
F_CAB_FACT = SRC / "FACT_Cabinet-resolution.xlsx"
F_IHA = SRC / "IHA.xlsx"
F_DOCS = SRC / "Cabinet-resolution-documents.docx"


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def clean(v) -> str:
    """Normalise a cell to a trimmed string ('' when missing)."""
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return ""
    s = str(v).replace(" ", " ").strip()
    if s.lower() in {"nan", "nat", "none"}:
        return ""
    return re.sub(r"[ \t]+", " ", s)


def group_no(label: str) -> int:
    """Sort key for 'กลุ่มมติ 12 ...' -> 12; 'อื่นๆ' -> 99."""
    m = re.search(r"กลุ่มมติ\s*(\d+)", label)
    return int(m.group(1)) if m else 99


def resolution_no(rid: str) -> tuple:
    """Sort key for 'มติ 12.3' -> (12, 3)."""
    m = re.search(r"(\d+)\.(\d+)", rid)
    return (int(m.group(1)), int(m.group(2))) if m else (999, 999)


THAI_DIGITS = str.maketrans("๐๑๒๓๔๕๖๗๘๙", "0123456789")


def arabic(s: str) -> str:
    """'๑๒.๓' -> '12.3' — the Word document numbers everything in Thai digits."""
    return s.translate(THAI_DIGITS)


# --------------------------------------------------------------------------- #
# 0. Document links (Word table: one row per cabinet agenda item)
# --------------------------------------------------------------------------- #
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"


def read_doc_links(path: Path) -> tuple[dict, dict]:
    """
    Pull the Google Drive links out of the "ไฟล์เอกสารแนบ" column.

    Each link is labelled either with a single resolution ("๑.๒ …" -> มติ 1.2)
    or with a whole assembly ("NHA ๖-๗" -> every resolution of assemblies 6
    and 7). Returns (per_resolution, per_assembly) keyed by id / assembly no.
    """
    if not path.exists():
        return {}, {}

    with zipfile.ZipFile(path) as z:
        rels = ET.fromstring(z.read("word/_rels/document.xml.rels"))
        doc = ET.fromstring(z.read("word/document.xml"))

    target = {
        rel.get("Id"): rel.get("Target")
        for rel in rels
        if rel.get("Type", "").endswith("/hyperlink")
    }

    by_res: dict[str, dict] = {}
    by_assembly: dict[int, dict] = {}

    for para in doc.iter(W + "p"):
        for hl in para.iter(W + "hyperlink"):
            url = target.get(hl.get(R + "id"), "")
            if not url.startswith("http"):
                continue
            label = clean("".join(t.text or "" for t in para.iter(W + "t")))
            plain = arabic(label)

            # "NHA 6-7" / "NHA4" — a folder covering one or more whole assemblies
            m = re.match(r"NHA\s*(\d+)\s*(?:[-–]\s*(\d+))?\s*$", plain, re.I)
            if m:
                lo = int(m.group(1))
                hi = int(m.group(2) or m.group(1))
                for a in range(lo, hi + 1):
                    by_assembly[a] = {"url": url, "label": label}
                continue

            # "1.2 การเข้าถึงยาถ้วนหน้า…" — a folder for one resolution
            m = re.match(r"(\d+)\.(\d+)", plain)
            if m:
                by_res[f"มติ {m.group(1)}.{m.group(2)}"] = {"url": url, "label": label}

    return by_res, by_assembly


DOC_BY_RES, DOC_BY_ASSEMBLY = read_doc_links(F_DOCS)


# --------------------------------------------------------------------------- #
# 1. Resolutions (มติสมัชชาสุขภาพแห่งชาติ)
# --------------------------------------------------------------------------- #
name_df = pd.read_excel(F_NHA, sheet_name="FACT_Name_NHA")
name_df = name_df.map(clean) if hasattr(name_df, "map") else name_df.applymap(clean)

resolutions: dict[str, dict] = {}
for _, r in name_df.iterrows():
    rid = r["ID_NHA"]
    if not rid:
        continue
    year = r["YEAR_NHA"]
    year_i = int(float(year)) if re.fullmatch(r"\d+(\.0)?", year) else None
    resolutions[rid] = {
        "id": rid,
        "name": r["Name_NHA"],
        # strip the leading "มติ x.y " prefix for a cleaner display title
        "title": re.sub(r"^มติ\s*[\d.]+\s*", "", r["Name_NHA"]).strip(),
        "group": r["Group_NHA"] or "อื่นๆ",
        "year": year_i,
        "assembly": resolution_no(rid)[0],
        "source": r["Source_NHA"],
        "sourceDetail": r["source_NHA_details"],
        "status": r["status_NHA"] or "ไม่ระบุ",
        "driven": [],
        "cabinet": [],
        "cabinetStatus": "",
    }

    # a folder for this exact resolution wins; otherwise fall back to the
    # folder covering its whole assembly
    assembly = resolution_no(rid)[0]
    doc = DOC_BY_RES.get(rid)
    scope = "resolution"
    if not doc:
        doc = DOC_BY_ASSEMBLY.get(assembly)
        scope = "assembly"
    resolutions[rid]["docLink"] = doc["url"] if doc else ""
    resolutions[rid]["docScope"] = scope if doc else ""

# --------------------------------------------------------------------------- #
# 2. Driving actions (การขับเคลื่อนมติ)
# --------------------------------------------------------------------------- #
ORG_GROUP_FIX = {
    "ภาครัฐ": "ภาครัฐ",
    "ภาคประชาสังคม/เอกชน": "ภาคประชาสังคม/เอกชน",
    "ภาคเอกชน": "ภาคเอกชน",
    "ภาควิชาการ": "ภาควิชาการ",
    "องค์กรวิชาชีพ": "องค์กรวิชาชีพ",
}

driven_df = pd.read_excel(F_NHA, sheet_name="FACT_driven_NHA")
driven_df = driven_df.map(clean) if hasattr(driven_df, "map") else driven_df.applymap(clean)

actions: list[dict] = []
for _, r in driven_df.iterrows():
    rid = r["ID_NHA"]
    if not rid:
        continue
    org = r["org_driving_NHA"]
    grp = ORG_GROUP_FIX.get(r["Group_org"], r["Group_org"] or "ไม่ระบุ")
    issue = r["driven_issues_NHA"] or "ไม่ระบุ"
    rec = {
        "resId": rid,
        "resName": resolutions.get(rid, {}).get("name", r["Name_NHA"]),
        "org": org or "ไม่ระบุ",
        "orgGroup": grp,
        "issue": issue,
        "detail": r["details_driven_NHA"],
    }
    actions.append(rec)
    if rid in resolutions:
        resolutions[rid]["driven"].append(rec)

# --------------------------------------------------------------------------- #
# 3. Cabinet resolutions (มติคณะรัฐมนตรี)
# --------------------------------------------------------------------------- #
cab_fact = pd.read_excel(F_CAB_FACT)
cabinet: dict[str, dict] = {}
for _, r in cab_fact.iterrows():
    cid = clean(r["ID มติครม"])
    if not cid:
        continue
    d = r["วันที่มีมติ ครม."]
    # NOTE: the source workbook stores the *Buddhist-era* year inside the date
    # cell (e.g. 2552-05-19 means 19 May 2552 BE = 2009 CE), so no +543 here.
    date = "" if pd.isna(d) else pd.Timestamp(d).strftime("%Y-%m-%d")
    cabinet[cid] = {
        "id": cid,
        "date": date,
        "year": int(date[:4]) if date else None,
        "title": clean(r["ชื่อเรื่อง"]),
        "detail": clean(r["รายละเอียดมติ ครม."]),
        "link": clean(r.get("Unnamed: 4")) if clean(r.get("Unnamed: 4")).startswith("http") else "",
        "resolutions": [],
    }

link_df = pd.read_excel(F_CAB_LINK)
link_df = link_df.map(clean) if hasattr(link_df, "map") else link_df.applymap(clean)

cab_links: list[dict] = []
for _, r in link_df.iterrows():
    rid = r["ID_NHA"]
    # "NO" is a sentinel used in the source sheet for "no cabinet resolution"
    cid = "" if r["ID มติครม"].upper() == "NO" else r["ID มติครม"]
    status = r["สถานะการเข้าครม."] or "ไม่ระบุ"
    rec = {
        "resId": rid,
        "resName": r["Name_NHA"],
        "tool": r["เครื่องมือ"] or "ไม่ระบุ",
        "cabStatus": status,
        "cabId": cid,
        "cabTitle": r["ชื่อมติ"],
        "cabDate": cabinet.get(cid, {}).get("date", ""),
    }
    cab_links.append(rec)
    if rid in resolutions:
        resolutions[rid]["cabinet"].append(rec)
        # keep the "best" status: a real submission beats a pending/none marker
        prev = resolutions[rid]["cabinetStatus"]
        if not prev or (prev.startswith(("ไม่", "อยู่")) and status.startswith("ครั้ง")):
            resolutions[rid]["cabinetStatus"] = status
    if cid in cabinet:
        cabinet[cid]["resolutions"].append({"id": rid, "name": r["Name_NHA"]})

for res in resolutions.values():
    if not res["cabinetStatus"]:
        res["cabinetStatus"] = "ไม่มีข้อมูล"

# --------------------------------------------------------------------------- #
# 4. Issue-specific assemblies (สมัชชาเฉพาะประเด็น / IHA)
# --------------------------------------------------------------------------- #
iha_df = pd.read_excel(F_IHA, sheet_name="FACT_Name_IHA")
iha_df = iha_df.map(clean) if hasattr(iha_df, "map") else iha_df.applymap(clean)
iha = [
    {"id": r["ID_IHA"], "name": r["Name_IHA"], "group": r["Group_IHA"], "year": r["YEAR_IHA"]}
    for _, r in iha_df.iterrows()
    if r["ID_IHA"]
]

# --------------------------------------------------------------------------- #
# 5. Dimensions
# --------------------------------------------------------------------------- #
dim_group = pd.read_excel(F_NHA, sheet_name="DIM_Group_NHA")
groups = sorted({clean(g) for g in dim_group["Group_NHA"] if clean(g)} |
                {r["group"] for r in resolutions.values()}, key=group_no)

dim_issue = pd.read_excel(F_NHA, sheet_name="DIM_driven_issues_NHA")
issues = [clean(i) for i in dim_issue["driven_issues_NHA"] if clean(i)]
for a in actions:
    if a["issue"] not in issues:
        issues.append(a["issue"])

dim_status = pd.read_excel(F_NHA, sheet_name="DIM_status_NHA")
statuses = [clean(s) for s in dim_status["สถานะการขับเคลื่อน"] if clean(s)]

# --------------------------------------------------------------------------- #
# 6. Write payload
# --------------------------------------------------------------------------- #
res_list = sorted(resolutions.values(), key=lambda r: resolution_no(r["id"]))
for r in res_list:
    r["drivenCount"] = len(r["driven"])
    r["orgCount"] = len({d["org"] for d in r["driven"]})
    r["cabinetCount"] = len({c["cabId"] for c in r["cabinet"] if c["cabId"]})
    # the detail rows live in `actions` / `cabinetLinks`; the dashboard joins
    # them on resId, so drop the nested copies to keep the payload small
    del r["driven"], r["cabinet"]

payload = {
    "meta": {
        "title": "มติสมัชชาสุขภาพแห่งชาติ",
        "titleEn": "National Health Assembly Resolutions",
        "source": "สำนักงานคณะกรรมการสุขภาพแห่งชาติ (สช.) / NHCO",
        "generated": pd.Timestamp.utcnow().strftime("%Y-%m-%d"),
        "counts": {
            "resolutions": len(res_list),
            "actions": len(actions),
            "orgs": len({a["org"] for a in actions}),
            "cabinet": len(cabinet),
            "docLinks": sum(1 for r in res_list if r["docLink"]),
        },
    },
    "resolutions": res_list,
    "actions": actions,
    "cabinet": sorted(cabinet.values(), key=lambda c: c["date"]),
    "cabinetLinks": cab_links,
    "iha": iha,
    "dims": {
        "groups": groups,
        "issues": issues,
        "statuses": statuses,
        "orgGroups": sorted({a["orgGroup"] for a in actions}),
        "years": sorted({r["year"] for r in res_list if r["year"]}),
        "cabStatuses": sorted({c["cabStatus"] for c in cab_links}),
    },
}

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")

print(f"wrote {OUT.relative_to(ROOT)}  ({OUT.stat().st_size/1024:.0f} KB)")
for k, v in payload["meta"]["counts"].items():
    print(f"  {k:12s} {v}")
n_exact = sum(1 for r in res_list if r["docScope"] == "resolution")
n_asm = sum(1 for r in res_list if r["docScope"] == "assembly")
print(f"  doc links    {n_exact + n_asm} ({n_exact} per-resolution, {n_asm} per-assembly, "
      f"{len(res_list) - n_exact - n_asm} without)")
