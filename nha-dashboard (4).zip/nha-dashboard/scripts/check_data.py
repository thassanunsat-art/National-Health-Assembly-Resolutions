#!/usr/bin/env python3
"""Sanity checks for data/nha_data.json — run in CI after build_data.py."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
data = json.loads((ROOT / "data" / "nha_data.json").read_text(encoding="utf-8"))

errors: list[str] = []


def check(cond: bool, msg: str) -> None:
    if not cond:
        errors.append(msg)


res = data["resolutions"]
acts = data["actions"]
cab = data["cabinet"]
links = data["cabinetLinks"]
ids = {r["id"] for r in res}

check(len(res) > 50, f"expected >50 resolutions, got {len(res)}")
check(len(acts) > 200, f"expected >200 actions, got {len(acts)}")
check(len(cab) > 10, f"expected >10 cabinet resolutions, got {len(cab)}")

check(len(ids) == len(res), "duplicate resolution IDs")
check(all(r["year"] for r in res), "resolution(s) missing a year")
check(all(2540 < r["year"] < 2600 for r in res if r["year"]), "year outside the Buddhist-era range")
check(all(r["status"] for r in res), "resolution(s) missing a status")

orphan_acts = {a["resId"] for a in acts} - ids
check(not orphan_acts, f"actions referencing unknown resolutions: {sorted(orphan_acts)[:5]}")

cab_ids = {c["id"] for c in cab}
orphan_links = {l["cabId"] for l in links if l["cabId"]} - cab_ids
check(not orphan_links, f"cabinet links referencing unknown resolutions: {sorted(orphan_links)[:5]}")

counts = data["meta"]["counts"]
check(counts["resolutions"] == len(res), "meta.counts.resolutions out of sync")
check(counts["actions"] == len(acts), "meta.counts.actions out of sync")

for dim in ("groups", "issues", "statuses", "orgGroups", "years"):
    check(bool(data["dims"][dim]), f"empty dimension: {dim}")

unknown_status = {r["status"] for r in res} - set(data["dims"]["statuses"])
check(not unknown_status, f"status values outside DIM_status_NHA: {unknown_status}")

# document links harvested from the Word source
linked = [r for r in res if r["docLink"]]
check(len(linked) > 40, f"expected >40 resolutions with a document link, got {len(linked)}")
check(
    all(r["docLink"].startswith("https://") for r in linked),
    "a document link is not an https URL",
)
check(
    all(r["docScope"] in {"resolution", "assembly"} for r in linked),
    "a document link has an unknown scope",
)
check(
    all(not r["docScope"] for r in res if not r["docLink"]),
    "a resolution has a scope but no document link",
)

if errors:
    print("FAILED:")
    for e in errors:
        print("  -", e)
    sys.exit(1)

print(
    f"OK — {len(res)} resolutions, {len(acts)} actions, "
    f"{counts['orgs']} organizations, {len(cab)} cabinet resolutions, "
    f"{len(linked)} with document links"
)
